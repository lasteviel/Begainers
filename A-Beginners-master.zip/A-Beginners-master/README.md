This Script Helps You Install All basic Commands 


Don't Copy this code without give me the credit, nerd!


#usage


cd A-Beginners 

ls

chmod +x installer.sh


bash installer.sh 
